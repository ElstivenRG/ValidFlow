/// <reference types="@nativescript/types" />
